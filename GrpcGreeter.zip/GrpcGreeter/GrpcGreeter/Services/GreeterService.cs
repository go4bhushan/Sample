using Grpc.Core;
using GrpcGreeter;

namespace GrpcGreeter.Services
{
    public class GreeterService : Greeter.GreeterBase
    {
        private readonly ILogger<GreeterService> _logger;
        public GreeterService(ILogger<GreeterService> logger)
        {
            _logger = logger;
        }

        public override async Task SendMessage(
            IAsyncStreamReader<ClientToServerMessage> requestStream,
            IServerStreamWriter<ServerToClientMessage> responseStream,
            ServerCallContext context)
        {
            var client = ClientToServerPingHandler(requestStream, responseStream, context);

            var server = ServerToClient(responseStream, context);

            await Task.WhenAll(client, server);
        }

        private static async Task ServerToClient(IServerStreamWriter<ServerToClientMessage> responseStream, ServerCallContext context)
        {
            var pingCount = 0;
            while (!context.CancellationToken.IsCancellationRequested)
            {
                if (context.RequestHeaders[1].Value == "c1")
                {
                    await responseStream.WriteAsync(new ServerToClientMessage
                    {
                        Text = $"Server said {++pingCount}-{context.RequestHeaders[1].Value}-{DateTime.Now.Ticks}",
                    });
                }
                else
                {
                    await responseStream.WriteAsync(new ServerToClientMessage
                    {
                        Text = $"Server said {++pingCount}-{context.RequestHeaders[1].Value}-{DateTime.Now.Ticks}",
                    });
                }

                await Task.Delay(5000);
            }
        }

        private async Task ClientToServerPingHandler(IAsyncStreamReader<ClientToServerMessage> requestStream,
            IServerStreamWriter<ServerToClientMessage> responseStream,
            ServerCallContext context)
        {
            while (await requestStream.MoveNext() && !context.CancellationToken.IsCancellationRequested)
            {
                var message = requestStream.Current;
                _logger.LogInformation($"The client said:{message.Text} - {context.RequestHeaders[1].Key}- {context.RequestHeaders[1].Value}");

                await responseStream.WriteAsync(new ServerToClientMessage
                {
                    Text = $"After Received -{message.Text} - {context.RequestHeaders[1].Key}- {context.RequestHeaders[1].Value}",
                });
            }
        }
    }
}